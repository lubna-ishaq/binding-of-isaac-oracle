// PixelHeart.jsx  -- eigenes Pixel-Art, keine Spiel-Assets.
// Ein <svg> aus <rect>-Pixeln: skaliert verlustfrei, faerbbar, animierbar.
//
//   <PixelHeart type="red" state="half" size={48} />
//   <PixelHeart type="soul" ratio={0.5} />
//   <HeartRow type="red" hp={5} max={12} />
//
// Nicht jeder Typ hat alle Zustaende -- siehe STATES_BY_TYPE. Ein Zustand,
// den es fuer den Typ nicht gibt, rendert nichts (Platzhalter in voller Groesse).

import React, { useMemo, useState, useCallback } from "react";

export const SIZE = 16;

/** Pixelformen, lauflaengen-kodiert als "y:x1-x2,x3;y2:..." */
const SHAPES = {
  "heart": {
    "outline": "1:2-6,9-13;2:1-2,6-9,13-14;3:0-1,7-8,14-15;4:0,15;5:0,15;6:0,15;7:0-1,14-15;8:1,14;9:1-2,13-14;10:2-3,12-13;11:3-4,11-12;12:4-5,10-11;13:5-6,9-10;14:6-9",
    "base": "2:3-5,10-11;3:2,5-6,9-12;4:1,4-13;5:1,3-13;6:2-12;7:2-11;8:3-11;9:4-10;10:5-9;11:6-9;12:7-8",
    "shade": "2:12;3:13;4:14;5:14;6:1,13-14;7:12-13;8:2,12-13;9:3,11-12;10:4,10-11;11:5,10;12:6,9;13:7-8",
    "hi": "3:3-4;4:2-3;5:2",
    "rim": "2:3-5,10-12;3:2,6,9,13;4:1,7-8,14;5:1,14;6:1,14;7:2,13;8:2,13;9:3,12;10:4,11;11:5,10;12:6,9;13:7-8",
    "left": "2:3-5;3:2-6;4:1-7;5:1-7;6:1-7;7:2-7;8:2-7;9:3-7;10:4-7;11:5-7;12:6-7;13:7",
    "mid": 7
  },
  "cross": {
    "outline": "1:5-10;2:5,10;3:5,10;4:5,10;5:1-5,10-14;6:1,14;7:1,14;8:1,14;9:1,14;10:1-5,10-14;11:5,10;12:5,10;13:5,10;14:5-10",
    "base": "2:8;3:7-8;4:6-8;5:6-8;6:4-12;7:3-12;8:2-12;9:6-9;10:6-8;11:6-8;12:6-8",
    "shade": "2:9;3:9;4:9;5:9;6:13;7:13;8:13;9:2-5,10-13;10:9;11:9;12:9;13:6-9",
    "hi": "2:6-7;3:6;6:2-3;7:2",
    "rim": "2:6-9;3:6,9;4:6,9;5:6,9;6:2-5,10-13;7:2,13;8:2,13;9:2-5,10-13;10:6,9;11:6,9;12:6,9;13:6-9",
    "left": "2:6-7;3:6-7;4:6-7;5:6-7;6:2-7;7:2-7;8:2-7;9:2-7;10:6-7;11:6-7;12:6-7;13:6-7",
    "mid": 7
  }
};

/** Detail-Ebenen */
const DETAILS = {
  "boneRibs": "6:5-6,8-9;8:4-6,8-10;10:5-6,8-9",
  "boneSternum": "5:7;6:7;7:7;8:7;9:7;10:7;11:7",
  "rotMarks": "5:2-3;6:3;7:2;8:4-5;9:4;11:6",
  "crack": "4:7;5:8;6:9;7:8;8:8;9:7;10:8;11:7;12:7"
};

/** Paletten inkl. gueltiger Zustaende je Typ */
export const PALETTES = {
  "red": {
    "base": "#d02b3a",
    "shade": "#8f1524",
    "hi": "#ff7d88",
    "outline": "#1e0a0f",
    "emptyBase": "#3a1522",
    "emptyShade": "#27101d",
    "emptyHi": "#572e3a",
    "states": [
      "full",
      "half",
      "empty"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Red Heart"
  },
  "bone": {
    "base": "#e8e2cc",
    "shade": "#aaa184",
    "hi": "#fffaf0",
    "outline": "#2b2618",
    "emptyBase": "#3f393f",
    "emptyShade": "#2b252c",
    "emptyHi": "#575157",
    "states": [
      "full",
      "half",
      "empty"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Bone Heart",
    "marks": "#8d8265",
    "pits": "#5d5540"
  },
  "gold": {
    "base": "#f0c33c",
    "shade": "#b1802a",
    "hi": "#fff4b3",
    "outline": "#4a3405",
    "emptyBase": "#413322",
    "emptyShade": "#2c201e",
    "emptyHi": "#574f46",
    "states": [
      "full"
    ],
    "shape": "heart",
    "mode": "frame",
    "label": "Gold Heart",
    "rim": "#f5cf55"
  },
  "blended": {
    "base": "#d02b3a",
    "shade": "#8f1524",
    "hi": "#ff7d88",
    "outline": "#1e0a0f",
    "emptyBase": "#3a1522",
    "emptyShade": "#27101d",
    "emptyHi": "#572e3a",
    "states": [
      "full"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Blended Heart",
    "altBase": "#4f86e8",
    "altShade": "#2f56a8",
    "altHi": "#bfe0ff"
  },
  "rotten": {
    "base": "#7f9a3a",
    "shade": "#4e6224",
    "hi": "#c3d97a",
    "outline": "#1b220f",
    "emptyBase": "#2a2b22",
    "emptyShade": "#1e1b1d",
    "emptyHi": "#464836",
    "states": [
      "half"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Rotten Heart",
    "marks": "#3c4a1c"
  },
  "soul": {
    "base": "#4f86e8",
    "shade": "#2f56a8",
    "hi": "#bfe0ff",
    "outline": "#101a33",
    "emptyBase": "#212745",
    "emptyShade": "#191a31",
    "emptyHi": "#454a5c",
    "states": [
      "full",
      "half"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Soul Heart"
  },
  "black": {
    "base": "#5d4d80",
    "shade": "#332950",
    "hi": "#a996d6",
    "outline": "#120e1e",
    "emptyBase": "#231b30",
    "emptyShade": "#1a1324",
    "emptyHi": "#3e3550",
    "states": [
      "full",
      "half"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Black Heart"
  },
  "eternal": {
    "base": "#dfe9f2",
    "shade": "#a3b4c6",
    "hi": "#ffffff",
    "outline": "#27303c",
    "emptyBase": "#3d3b47",
    "emptyShade": "#2a2836",
    "emptyHi": "#57525c",
    "states": [
      "half"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Eternal Heart"
  },
  "broken": {
    "base": "#6b6b73",
    "shade": "#43434a",
    "hi": "#a9a9b3",
    "outline": "#15151a",
    "emptyBase": "#26212d",
    "emptyShade": "#1c1723",
    "emptyHi": "#3e3a46",
    "states": [
      "full"
    ],
    "shape": "heart",
    "mode": "solid",
    "label": "Broken Heart",
    "crack": "#15151a"
  },
  "holy": {
    "base": "#5aa0f0",
    "shade": "#2f63b8",
    "hi": "#d3e8ff",
    "outline": "#0f1f3d",
    "emptyBase": "#232c46",
    "emptyShade": "#191c33",
    "emptyHi": "#4a4c5c",
    "states": [
      "full"
    ],
    "shape": "cross",
    "mode": "solid",
    "label": "Holy Mantle"
  }
};

export const HEART_TYPES = [
  "red",
  "bone",
  "gold",
  "blended",
  "rotten",
  "soul",
  "black",
  "eternal",
  "broken",
  "holy"
];

/** Welche Zustaende es je Typ ueberhaupt gibt. */
export const STATES_BY_TYPE = Object.fromEntries(
  HEART_TYPES.map((t) => [t, PALETTES[t].states])
);

export const hasState = (type, state) =>
  !!PALETTES[type] && PALETTES[type].states.includes(state);

// --- RLE -> Pixelliste -------------------------------------------------------
function expand(rle) {
  const out = [];
  if (!rle) return out;
  for (const part of rle.split(";")) {
    const [ys, runs] = part.split(":");
    const y = +ys;
    for (const run of runs.split(",")) {
      const dash = run.indexOf("-");
      const lo = dash < 0 ? +run : +run.slice(0, dash);
      const hi = dash < 0 ? lo : +run.slice(dash + 1);
      for (let x = lo; x <= hi; x++) out.push([x, y]);
    }
  }
  return out;
}

const SH = Object.fromEntries(
  Object.entries(SHAPES).map(([name, s]) => [
    name,
    {
      outline: expand(s.outline),
      base: expand(s.base),
      shade: expand(s.shade),
      hi: expand(s.hi),
      rim: new Set(expand(s.rim).map(([x, y]) => x + "," + y)),
      left: new Set(expand(s.left).map(([x, y]) => x + "," + y)),
      mid: s.mid,
    },
  ])
);
const D = Object.fromEntries(
  Object.entries(DETAILS).map(([k, v]) => [k, expand(v)])
);

// --- Farbkarte fuer eine Typ/Zustand-Kombination -----------------------------
function buildPixels(type, state, override) {
  const p = { ...(PALETTES[type] || PALETTES.red), ...(override || {}) };
  const s = SH[p.shape] || SH.heart;
  const map = new Map();
  const put = ([x, y], c) => map.set(y * SIZE + x, c);

  // Gold: nur aeusserer Rahmen, innen transparent
  if (p.mode === "frame") {
    for (const pt of s.outline) put(pt, p.outline);
    for (const [k] of [["base"], ["shade"], ["hi"]])
      for (const pt of s[k]) if (s.rim.has(pt[0] + "," + pt[1])) put(pt, p.rim);
    for (const pt of s.hi) if (s.rim.has(pt[0] + "," + pt[1])) put(pt, p.hi);
    return map;
  }

  const lit = ([x, y]) =>
    state === "full" ? true : state === "empty" ? false : s.left.has(x + "," + y);

  for (const pt of s.outline) put(pt, p.outline);

  for (const [key, empt] of [["base", "emptyBase"], ["shade", "emptyShade"], ["hi", "emptyHi"]]) {
    for (const pt of s[key]) {
      const on = lit(pt);
      const alt = type === "blended" && !s.left.has(pt[0] + "," + pt[1]);
      const cap = key.charAt(0).toUpperCase() + key.slice(1);
      const norm = alt && p["alt" + cap] ? p["alt" + cap] : p[key];
      put(pt, on ? norm : p[empt]);
    }
  }

  const detail = (pts, color, onlyLit = true) => {
    if (!color) return;
    for (const pt of pts) if (!onlyLit || lit(pt)) put(pt, color);
  };

  if (type === "bone") { detail(D.boneRibs, p.marks); detail(D.boneSternum, p.marks); }
  if (type === "rotten") detail(D.rotMarks, p.marks);
  if (type === "broken") detail(D.crack, p.crack, false);

  return map;
}

// --- Pixel -> waagerechte Rechtecke (weniger DOM-Knoten) ---------------------
function toRects(map) {
  const rects = [];
  for (let y = 0; y < SIZE; y++) {
    let x = 0;
    while (x < SIZE) {
      const c = map.get(y * SIZE + x);
      if (!c) { x++; continue; }
      let w = 1;
      while (x + w < SIZE && map.get(y * SIZE + x + w) === c) w++;
      rects.push({ x, y, w, c });
      x += w;
    }
  }
  return rects;
}

const cache = new Map();
function rectsFor(type, state) {
  const key = type + "|" + state;
  let r = cache.get(key);
  if (!r) { r = toRects(buildPixels(type, state)); cache.set(key, r); }
  return r;
}

/** Anteil 0..1 auf den naechstbesten Zustand abbilden, den es fuer den Typ gibt. */
export function ratioToState(type, ratio) {
  const av = STATES_BY_TYPE[type] || ["full"];
  const want = ratio >= 0.75 ? ["full", "half", "empty"]
             : ratio >= 0.25 ? ["half", "full", "empty"]
             : ["empty", "half", "full"];
  return want.find((s) => av.includes(s)) ?? av[0];
}

/**
 * @param type        einer aus HEART_TYPES
 * @param state       "full" | "half" | "empty" -- gibt es den Zustand fuer den
 *                    Typ nicht, rendert die Komponente nichts
 * @param ratio       0..1, wird auf einen gueltigen Zustand gerundet
 * @param size        Kantenlaenge in px (Default 32)
 * @param interactive Klick schaltet durch die gueltigen Zustaende des Typs
 * @param colors      Palette punktuell ueberschreiben
 */
export default function PixelHeart({
  type = "red",
  state,
  ratio,
  size = 32,
  interactive = false,
  onChange,
  colors,
  title,
  className,
  style,
  ...rest
}) {
  const av = STATES_BY_TYPE[type] || ["full"];
  const [inner, setInner] = useState(av[0]);
  const resolved =
    state ?? (ratio !== undefined ? ratioToState(type, ratio) : inner);
  const visible = av.includes(resolved);

  const rects = useMemo(
    () => (!visible ? [] :
      colors ? toRects(buildPixels(type, resolved, colors)) : rectsFor(type, resolved)),
    [type, resolved, colors, visible]
  );

  const click = useCallback(() => {
    if (!interactive) return;
    const i = av.indexOf(resolved);
    const next = av[(i + 1) % av.length];
    if (state === undefined && ratio === undefined) setInner(next);
    onChange?.(next);
  }, [interactive, av, resolved, state, ratio, onChange]);

  return (
    <svg
      viewBox={`0 0 ${SIZE} ${SIZE}`}
      width={size}
      height={size}
      shapeRendering="crispEdges"
      role="img"
      aria-label={title ?? (visible ? `${type} heart ${resolved}` : "")}
      aria-hidden={visible ? undefined : true}
      className={className}
      onClick={interactive ? click : rest.onClick}
      style={{ cursor: interactive ? "pointer" : undefined, display: "block", ...style }}
      {...rest}
    >
      {title ? <title>{title}</title> : null}
      {rects.map((r, i) => (
        <rect key={i} x={r.x} y={r.y} width={r.w} height={1} fill={r.c} />
      ))}
    </svg>
  );
}

/**
 * Lebensleiste. hp zaehlt in halben Herzen: hp=5 -> zwei volle + ein halbes.
 *
 * Typen ohne "empty" (soul, black ...) zeichnen keine leeren Plaetze --
 * eine leere Seelenherz-Huelle gibt es im Spiel nicht.
 */
export function HeartRow({
  hp = 6,
  max = 12,
  type = "red",
  size = 32,
  gap = 2,
  interactive = false,
  onChange,
  ...rest
}) {
  const av = STATES_BY_TYPE[type] || ["full"];
  const showsEmpty = av.includes("empty");
  const slots = showsEmpty ? Math.ceil(max / 2) : Math.ceil(Math.min(hp, max) / 2);

  return (
    <div style={{ display: "flex", gap, alignItems: "center" }} {...rest}>
      {Array.from({ length: slots }, (_, i) => {
        const left = hp - i * 2;
        const st = left >= 2 ? "full" : left === 1 ? "half" : "empty";
        return (
          <PixelHeart
            key={i}
            type={type}
            state={av.includes(st) ? st : undefined}
            size={size}
            interactive={interactive}
            onChange={() => onChange?.(i)}
          />
        );
      })}
    </div>
  );
}
