// SpriteHeart.jsx -- PNG-Variante fuer alle, die lieber Bilddateien nutzen.
// Erwartet die Dateien aus dist/png/<scale>x/ im public-Ordner, z.B.
//   public/hearts/red-full.png

import React from "react";

export const HEART_TYPES = [
  "red",
  "bone",
  "gold",
  "blended",
  "rotten",
  "soul",
  "black",
  "eternal",
  "broken",
  "holy"
];
export const STATES_BY_TYPE = {
  "red": [
    "full",
    "half",
    "empty"
  ],
  "bone": [
    "full",
    "half",
    "empty"
  ],
  "gold": [
    "full"
  ],
  "blended": [
    "full"
  ],
  "rotten": [
    "half"
  ],
  "soul": [
    "full",
    "half"
  ],
  "black": [
    "full",
    "half"
  ],
  "eternal": [
    "half"
  ],
  "broken": [
    "full"
  ],
  "holy": [
    "full"
  ]
};
export const hasState = (t, s) => !!STATES_BY_TYPE[t] && STATES_BY_TYPE[t].includes(s);

export default function SpriteHeart({
  type = "red",
  state = "full",
  size = 32,
  basePath = "/hearts",
  alt,
  ...rest
}) {
  if (!hasState(type, state)) {
    return <span aria-hidden style={{ display: "block", width: size, height: size }} />;
  }
  return (
    <img
      src={`${basePath}/${type}-${state}.png`}
      width={size}
      height={size}
      alt={alt ?? `${type} heart ${state}`}
      draggable={false}
      style={{ imageRendering: "pixelated", display: "block" }}
      {...rest}
    />
  );
}

/** Variante ueber das Spritesheet (ein einziger Request). */
export function SheetHeart({
  type = "red",
  state = "full",
  size = 32,
  sheet = "/hearts/hearts-spritesheet.png",
  frame = 64,   // Kachelgroesse im Sheet (16px * 4)
  cols = 3,
  ...rest
}) {
  if (!hasState(type, state)) {
    return <span aria-hidden style={{ display: "block", width: size, height: size }} />;
  }
  const col = STATES_BY_TYPE[type].indexOf(state);   // Spalte = Position in der Typ-Liste
  const row = HEART_TYPES.indexOf(type);
  const k = size / frame;
  return (
    <div
      role="img"
      aria-label={`${type} heart ${state}`}
      style={{
        width: size,
        height: size,
        backgroundImage: `url(${sheet})`,
        backgroundPosition: `${-col * frame * k}px ${-row * frame * k}px`,
        backgroundSize: `${cols * frame * k}px ${HEART_TYPES.length * frame * k}px`,
        imageRendering: "pixelated",
      }}
      {...rest}
    />
  );
}
