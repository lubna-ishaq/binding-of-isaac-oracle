# Pixel Heart Kit

10 Herz-Typen, 16 Sprites, Pixel-Art im 16×16-Raster — einmal als React-SVG-Komponente,
einmal als PNG-Set.

> Eigenes Artwork im Retro-Stil, keine Original-Assets aus dem Spiel. Formen und Paletten
> sind neu gezeichnet, damit du sie frei in deinem Projekt verwenden kannst.

## Typen und Zustände

Nicht jeder Typ hat alle drei Zustände — das Set bildet ab, was es tatsächlich gibt.

| Key | Name | full | half | empty | Anmerkung |
|---|---|:--:|:--:|:--:|---|
| `red` | Red Heart | ✓ | ✓ | ✓ | voller Container, einziger Typ mit allen drei |
| `bone` | Bone Heart | ✓ | ✓ | ✓ | Rippenbogen + Brustbein als eigene Ebene |
| `gold` | Gold Heart | ✓ | — | — | **nur Rahmen**, innen transparent — Overlay |
| `blended` | Blended Heart | ✓ | — | — | links rot, rechts blau |
| `rotten` | Rotten Heart | — | ✓ | — | belegt einen halben Platz |
| `soul` | Soul Heart | ✓ | ✓ | — | keine leere Hülle |
| `black` | Black Heart | ✓ | ✓ | — | keine leere Hülle |
| `eternal` | Eternal Heart | — | ✓ | — | nur halb |
| `broken` | Broken Heart | ✓ | — | — | nur ganz |
| `holy` | Holy Mantle | ✓ | — | — | blaues Kreuz, kein Herz |

Zur Laufzeit steht dieselbe Tabelle als `STATES_BY_TYPE` bereit, plus `hasState(type, state)`.

## Variante A — SVG-Komponente (empfohlen)

Kopiere `react/PixelHeart.jsx` in dein Projekt. Keine Abhängigkeiten außer React,
die Pixeldaten stecken in der Datei.

```jsx
import PixelHeart, { HeartRow, STATES_BY_TYPE, hasState } from "./PixelHeart";

<PixelHeart type="red" state="half" size={48} />
<PixelHeart type="soul" ratio={hp / maxHp} />          // auf gültigen Zustand gerundet
<PixelHeart type="black" interactive onChange={s => ...} />
<PixelHeart type="red" colors={{ base: "#ff2e88" }} /> // Palette überschreiben

<HeartRow hp={5} max={12} type="red" size={40} />      // hp zählt halbe Herzen
```

**Ungültige Zustände zeichnen nichts.** `<PixelHeart type="soul" state="empty" />` gibt ein
leeres SVG in voller Größe zurück — das Layout springt nicht, aber es ist nichts zu sehen.
Das ist Absicht: eine leere Seelenherz-Hülle gibt es nicht.

### Gold ist ein Overlay

Das Gold Heart ist nur der äußere Rahmen, innen transparent. Leg ihn über ein rotes Herz:

```jsx
<div style={{ position: "relative" }}>
  <PixelHeart type="red" state="full" size={48} />
  <PixelHeart type="gold" size={48} style={{ position: "absolute", inset: 0 }} />
</div>
```

### Props `PixelHeart`

| Prop | Typ | Default | Bedeutung |
|---|---|---|---|
| `type` | Typ-Key | `"red"` | siehe Tabelle oben |
| `state` | `full \| half \| empty` | — | gibt es den Zustand nicht, wird nichts gezeichnet |
| `ratio` | `0…1` | — | wird auf den nächstbesten gültigen Zustand gerundet |
| `size` | `number` | `32` | Kantenlänge in px |
| `interactive` | `boolean` | `false` | Klick schaltet durch die gültigen Zustände |
| `onChange` | `(state) => void` | — | Callback beim Umschalten |
| `colors` | `object` | — | überschreibt einzelne Palettenwerte |

Palettenschlüssel: `base`, `shade`, `hi`, `outline`, `emptyBase`, `emptyShade`, `emptyHi`
sowie typspezifisch `marks`, `crack`, `rim`, `altBase`/`altShade`/`altHi` (nur `blended`).

Das SVG nutzt `shapeRendering="crispEdges"` — pixelscharf bei jeder Größe, auch `size={37}`.

### `HeartRow`

`hp` zählt in halben Herzen. Typen ohne `empty` (soul, black, …) zeichnen keine leeren
Plätze: die Leiste wird kürzer, statt Hüllen zu zeigen, die es nicht gibt.

## Variante B — PNGs

```
png/1x/  16×16      png/4x/  64×64
png/2x/  32×32      png/8x/  128×128
```

Dateinamen: `<typ>-<zustand>.png`, z. B. `red-half.png`. Es gibt nur Dateien für gültige
Kombinationen — 16 Sprites × 4 Auflösungen = 64 Bilder.

```jsx
import SpriteHeart, { SheetHeart } from "./SpriteHeart";

<SpriteHeart type="red" state="half" size={48} basePath="/hearts" />
<SheetHeart  type="red" state="half" size={48} />   // ein einziger Request
```

Wichtig beim Skalieren: `image-rendering: pixelated`, sonst matscht der Browser die Kanten.
Die Wrapper setzen das schon.

`hearts-spritesheet.png` ist 192×640, Kachel 64×64. Eine Zeile je Typ, Spalten = dessen
gültige Zustände in der Reihenfolge aus `STATES_BY_TYPE`. Koordinaten in
`hearts-spritesheet.json`.

## Variante C — eigene Pipeline

`heart-data.json` enthält die Geometrie (lauflängen-kodiert) und alle Paletten — für Canvas,
WebGL, Unity oder was auch immer:

```js
{
  size: 16,
  shapes: {
    heart: { outline, base, shade, hi, rim, left, mid },   // "y:x1-x2,x3;y2:..."
    cross: { ... }                                          // Holy Mantle
  },
  details: { boneRibs, boneSternum, rotMarks, crack },
  palettes: { red: { base:"#d02b3a", states:["full","half","empty"], shape:"heart",
                     mode:"solid", ... }, ... },
  order: [...]
}
```

`mode: "frame"` (nur `gold`) heißt: nur `outline` + `rim` zeichnen, Rest transparent.

## Dateien

```
react/PixelHeart.jsx        SVG-Komponente + HeartRow
react/SpriteHeart.jsx       PNG- und Spritesheet-Wrapper
png/{1,2,4,8}x/*.png        64 Einzelbilder
hearts-spritesheet.png      Spritesheet (192×640)
hearts-spritesheet.json     Frame-Koordinaten
heart-data.json             Geometrie + Paletten
preview.html                interaktive Vorschau, einfach im Browser öffnen
```
